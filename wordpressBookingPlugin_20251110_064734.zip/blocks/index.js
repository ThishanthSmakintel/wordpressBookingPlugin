import './block.tsx';
import '../src/assets/styles/editor/index.scss';
import { initLogger } from '../src/utils/logger';

initLogger();